(async()=>{
  const esc = (v='') => String(v);
  try {
    const [news, institutions] = await Promise.all([
      fetch('/api/public/news',{headers:{Accept:'application/json'}}).then(r=>r.ok?r.json():[]),
      fetch('/api/public/institutions',{headers:{Accept:'application/json'}}).then(r=>r.ok?r.json():[])
    ]);
    const newsHost=document.querySelector('#news .news-list');
    if(newsHost && news.length){
      newsHost.replaceChildren(...news.slice(0,6).map((x,i)=>{
        const a=document.createElement('a'); a.href='#news';
        const n=document.createElement('span'); n.textContent=String(i+1).padStart(2,'0');
        const d=document.createElement('div'); const small=document.createElement('small'); small.textContent=x.created_at?new Date(x.created_at).toLocaleDateString('am-ET'):''; const b=document.createElement('b'); b.textContent=esc(x.title_am); d.append(small,b); a.append(n,d,document.createTextNode('→')); return a;
      }));
    }
    const grid=document.getElementById('institutionGrid');
    if(grid && institutions.length && window.ENEWARI_OFFICES){
      const byId=new Map(window.ENEWARI_OFFICES.map(x=>[x.id,x]));
      grid.replaceChildren(...institutions.map((x,i)=>{
        const local=byId.get(x.id)||{}; const card=document.createElement('article'); card.className='institution-item';
        const num=document.createElement('span'); num.textContent=String(i+1).padStart(2,'0');
        const icon=document.createElement('div'); icon.className='inst-icon'; icon.textContent=x.icon||local.icon||'🏛️';
        const h=document.createElement('h3'); h.textContent=x.name_am;
        const p=document.createElement('p'); p.textContent=x.name_en;
        const a=document.createElement('a'); a.href=`/office.html?id=${encodeURIComponent(x.id)}`; a.textContent='የቢሮው ገጽ →';
        card.append(num,icon,h,p,a); return card;
      }));
    }
    const ticker=document.getElementById('tickerTrack');
    if(ticker && news.length){
      ticker.replaceChildren(...news.slice(0,8).map(x=>{const a=document.createElement('a');a.href='#news';a.textContent=x.title_am;return a;}));
    }
  } catch (e) { console.warn('Portal API unavailable; static content remains.',e); }
})();

(async()=>{
  try{
    const s=await fetch('/api/public/settings',{headers:{Accept:'application/json'}}).then(r=>r.ok?r.json():{});
    const set=(sel,fn)=>{const el=document.querySelector(sel);if(el)fn(el)};
    set('#contact .contact-items',host=>{
      const items=[
        ['⌖','አድራሻ',s.address||'አልተሞላም'],
        ['☎','ስልክ',s.phone||'አልተሞላም'],
        ['✉','ኢሜል',s.email||'አልተሞላም'],
        ['f','Facebook',s.facebook?'ይከተሉን':'አልተሞላም'],
        ['♪','TikTok',s.tiktok?'ይከተሉን':'አልተሞላም'],
        ['⌖','አቅጣጫ',s.map_url?'ካርታ ላይ ይመልከቱ':'አልተሞላም']
      ];
      host.replaceChildren(...items.map(([icon,label,val])=>{const d=document.createElement('div');const sp=document.createElement('span');sp.textContent=icon;const b=document.createElement('b');b.textContent=label;const p=document.createElement('p');let a;if((label==='ስልክ'&&s.phone)||(label==='ኢሜል'&&s.email)||(label==='Facebook'&&s.facebook)||(label==='TikTok'&&s.tiktok)||(label==='አቅጣጫ'&&s.map_url)){a=document.createElement('a');a.href=label==='ስልክ'?'tel:'+s.phone.replace(/\s+/g,''):label==='ኢሜል'?'mailto:'+s.email:label==='Facebook'?s.facebook:label==='TikTok'?s.tiktok:s.map_url;a.target=label==='ስልክ'||label==='ኢሜል'?'_self':'_blank';a.rel='noopener';a.textContent=val;p.append(a)}else p.textContent=val;d.append(sp,b,p);return d;}));
    });
  }catch(e){console.warn('Site settings unavailable',e)}
})();
