const id = Number(new URLSearchParams(location.search).get('id')) || 1;
(async()=>{
  let office = (window.ENEWARI_OFFICES || []).find(x => x.id === id) || window.ENEWARI_OFFICES?.[0];
  try { const r=await fetch(`/api/public/institutions/${id}`); if(r.ok) office=await r.json(); } catch{}
  if(!office) return;
  document.title = `${office.name_am||office.am} | እነዋሪ Digital Mesob`;
  document.getElementById('officeIcon').textContent = office.icon || '🏛️';
  document.getElementById('officeName').textContent = office.name_am || office.am;
  document.getElementById('officeNameEn').textContent = office.name_en || office.en;
  document.getElementById('officeIntro').textContent = office.description_am || office.introAm || '';
  const host = document.getElementById('servicesList'); host.replaceChildren();
  const am = office.services_am ? office.services_am.split(/\r?\n/).map(x=>x.trim()).filter(Boolean) : (office.servicesAm||[]);
  const en = office.services_en ? office.services_en.split(/\r?\n/).map(x=>x.trim()).filter(Boolean) : (office.servicesEn||[]);
  am.forEach((item,i)=>{const card=document.createElement('article');card.className='service-row';const n=document.createElement('span');n.textContent=String(i+1).padStart(2,'0');const wrap=document.createElement('div');const b=document.createElement('b');b.textContent=item;const p=document.createElement('p');p.textContent=en[i]||'';wrap.append(b,p);card.append(n,wrap);host.append(card);});
  const aside=document.querySelector('.office-contact');
  if(aside){
    const details=[]; if(office.head_am) details.push(`<div><b>ኃላፊ</b><span>${escapeHtml(office.head_am)}</span></div>`); if(office.work_hours) details.push(`<div><b>የስራ ሰዓት</b><span>${escapeHtml(office.work_hours)}</span></div>`);
    if(details.length){const box=document.createElement('div');box.className='office-extra';box.innerHTML=details.join('');aside.insertBefore(box,aside.querySelector('small'))}
    const photo=office.photo_url; if(photo){const img=document.createElement('img');img.src=photo;img.alt=office.name_am||'';img.loading='lazy';img.className='office-photo';aside.prepend(img)}
    if(office.forms_url){const a=document.createElement('a');a.href=office.forms_url;a.target='_blank';a.rel='noopener';a.textContent='📄 ቅጾች / ሰነዶች';aside.insertBefore(a,aside.querySelector('small'))}
    if(office.phone){const a=[...aside.querySelectorAll('a')].find(x=>x.href.startsWith('tel:'));if(a){a.href='tel:'+office.phone.replace(/\s+/g,'');a.textContent='☎ '+office.phone}}
    if(office.email){const a=[...aside.querySelectorAll('a')].find(x=>x.href.startsWith('mailto:'));if(a){a.href='mailto:'+office.email;a.textContent='✉ '+office.email}}
  }
})();
function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
